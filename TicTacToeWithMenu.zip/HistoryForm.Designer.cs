﻿using System.Collections.Generic;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace TicTacToe
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 650);
            this.Text = "History Form";
            ReadFromFile();

            //
            //  _backBtn
            //
            this._backBtn = new Button();
            this._backBtn.Text = "Back";
            this._backBtn.Font = new System.Drawing.Font(_backBtn.Font.FontFamily, 15);
            this._backBtn.Click += (s, e) => this.Close();            
            this._backBtn.Size = new System.Drawing.Size(100, 70);
            this._backBtn.Location = new System.Drawing.Point((this.Width / 2) - (_backBtn.Width / 2), 
                this.Bottom-_backBtn.Height*2);
            this.Controls.Add(_backBtn);
        }
        private List<System.Windows.Forms.Label> _lastGames;
        private Button _backBtn;
        #endregion
    }
}