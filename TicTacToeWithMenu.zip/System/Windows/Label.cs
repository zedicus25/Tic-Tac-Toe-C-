﻿namespace System.Windows
{
    internal class Label
    {
    }
}