﻿using System.Drawing;
using System.Windows.Forms;

namespace TicTacToe
{
    partial class GameForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600,600);
            this.Text = "Tic Tac Toe";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Location = new System.Drawing.Point((_screenWidth /2) - (this.Size.Width/2), 
                (_screenHeight/2) - (this.Size.Height/2));
            this.BackColor = Color.Khaki;

            //
            //  _whoMoveL
            //
            this._whoMoveL = new System.Windows.Forms.Label();
            this._whoMoveL.Size = new Size(300, 80);
            this._whoMoveL.Text = $"Now move: {_firstUserName}";
            this._whoMoveL.TextAlign = ContentAlignment.TopCenter;
            this._whoMoveL.Font = new Font(this._whoMoveL.Font.FontFamily, 18);
            this._whoMoveL.Location = new Point((this.Width / 2) - (this._whoMoveL.Width / 2), 55);
            this.Controls.Add(_whoMoveL);


            this._field = new Button[_fiedlSize, _fiedlSize];
            this.CreateField();
        }
        private Label _whoMoveL;
        private Button[,] _field;
        private int _fiedlSize = 3;
        private bool _isX = true;
        private int _screenWidth = Screen.PrimaryScreen.Bounds.Width;
        private int _screenHeight = Screen.PrimaryScreen.Bounds.Height;
        #endregion

    }
}

