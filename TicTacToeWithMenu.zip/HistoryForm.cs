﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class HistoryForm : Form
    {
        public HistoryForm()
        {
            InitializeComponent();
        }

        private void ReadFromFile()
        {
            if (!File.Exists("history.txt"))
            {
                Label l = new Label();
                l.Text = "Not has data";
                l.Size = new Size(150, 50);
                l.Font = new Font(l.Font.FontFamily, 15);
                l.Location = new Point((this.Width / 2) - (l.Width / 2), (this.Height / 2) - (l.Height / 2));
                this.Controls.Add(l);
                return;
            }
            this._lastGames = new List<System.Windows.Forms.Label>(10);

            List<string> allLines = File.ReadAllLines("history.txt").ToList();
            if (allLines.Count > 10)
                allLines.RemoveRange(0, allLines.Count-10);
            allLines.RemoveAll(s => s.Equals(String.Empty));

            Label tmp = new Label();
            tmp.Text = allLines[0];
            tmp.Size = new Size(this.Width - 20, 50);
            tmp.Location = new Point(0, 0);
            tmp.Font = new Font(tmp.Font.FontFamily, 13);
            this._lastGames.Add(tmp);
            for (int i = 1; i < allLines.Count; i++)
            {
                Label tmp1 = new Label();
                tmp1.Text = allLines[i];
                tmp1.Size = new Size(this.Width - 20, 50);
                tmp1.Location = new Point(0, 50*i);
                tmp1.Font = new Font(tmp1.Font.FontFamily, 13);
                this._lastGames.Add(tmp1);
            }

            foreach (var l in this._lastGames)
            {
                this.Controls.Add(l);
            }
        }
    }
}
