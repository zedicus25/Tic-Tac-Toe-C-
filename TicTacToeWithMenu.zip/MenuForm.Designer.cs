﻿using System.Drawing;
using System.Windows.Forms;

namespace TicTacToe
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 600);
            this.Text = "Main Menu";
            this.Location = new System.Drawing.Point(500,500);
            this.MaximumSize = new System.Drawing.Size(450, 600);
            this.MinimumSize = new System.Drawing.Size(450, 600);
            this.BackColor = Color.LightGreen;

            //
            //  _nameL
            //
            _nameL = new System.Windows.Forms.Label();
            _nameL.Text = "Tic Tac Toe";
            _nameL.TextAlign = ContentAlignment.TopCenter;
            _nameL.Size = new Size(450, 55);
            _nameL.Location = new System.Drawing.Point((this.Size.Width / 2) - (_nameL.Width / 2),30);
            _nameL.ForeColor = Color.Black;
            _nameL.Font = new Font(_nameL.Font.FontFamily,30, FontStyle.Bold);
            this.Controls.Add(_nameL);

            //
            //  _newGameBut
            //
            _newGameBtn = new Button();
            _newGameBtn.Size = new System.Drawing.Size(260, 100);
            _newGameBtn.Location = new System.Drawing.Point((this.Size.Width/2) - (_newGameBtn.Width/2), 100);
            _newGameBtn.BackColor = Color.DarkOrange;
            _newGameBtn.ForeColor = Color.Black;
            _newGameBtn.Text = "Start new game";
            _newGameBtn.Font = new Font(_newGameBtn.Font.FontFamily, 20);
            _newGameBtn.Click += NewGameClick;
            this.Controls.Add(_newGameBtn);

            //
            //  _optionsBtn
            //
            _optionsBtn = new Button();
            _optionsBtn.Size = new System.Drawing.Size(260, 100);
            _optionsBtn.Location = new System.Drawing.Point((this.Size.Width / 2) - (_optionsBtn.Width / 2), 210);
            _optionsBtn.BackColor = Color.DarkOrange;
            _optionsBtn.ForeColor = Color.Black;
            _optionsBtn.Text = "Options";
            _optionsBtn.Font = new Font(_optionsBtn.Font.FontFamily, 20);
            _optionsBtn.Click += OptionsClick;
            this.Controls.Add(_optionsBtn);

            //
            //  _historyBtn
            //
            _historyBtn = new Button();
            _historyBtn.Size = new System.Drawing.Size(260, 100);
            _historyBtn.Location = new System.Drawing.Point((this.Size.Width / 2) - (_historyBtn.Width / 2), 320);
            _historyBtn.BackColor = Color.DarkOrange;
            _historyBtn.ForeColor = Color.Black;
            _historyBtn.Text = "Show history";
            _historyBtn.Font = new Font(_historyBtn.Font.FontFamily, 20);
            _historyBtn.Click += HistoryClick;
            this.Controls.Add(_historyBtn);

            //
            //  _historyBtn
            //
            _exitBtn = new Button();
            _exitBtn.Size = new System.Drawing.Size(260, 100);
            _exitBtn.Location = new System.Drawing.Point((this.Size.Width / 2) - (_exitBtn.Width / 2), 430);
            _exitBtn.BackColor = Color.DarkOrange;
            _exitBtn.ForeColor = Color.Black;
            _exitBtn.Text = "Exit";
            _exitBtn.Font = new Font(_exitBtn.Font.FontFamily, 20);
            _exitBtn.Click += (s,e) => Application.Exit();
            this.Controls.Add(_exitBtn);
        }


        private Label _nameL;
        private Button _newGameBtn;
        private Button _optionsBtn;
        private Button _historyBtn;
        private Button _exitBtn;
        #endregion
    }
}