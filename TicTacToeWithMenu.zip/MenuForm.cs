﻿using System.Drawing;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }
        private void NewGameClick(object sender, System.EventArgs e)
        {
            Form f = new StartGameForm();
            f.Location = new Point(500, 500);
            f.ShowDialog();
        }

        private void OptionsClick(object sender, System.EventArgs e)
        {
            Form f = new OptionsForm();
            f.Location = new Point(500, 500);
            f.ShowDialog();
        }

        private void HistoryClick(object sender, System.EventArgs e)
        {
            Form f = new HistoryForm();
            f.Location = new Point(500, 500);
            f.ShowDialog();
        }
    }
}
