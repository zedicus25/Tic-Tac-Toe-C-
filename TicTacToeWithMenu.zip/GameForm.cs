﻿using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class GameForm : Form
    {
        private string _firstUserName;
        private string _secondUserName;
        private DateTime _startTime;
        private DateTime _endTime;
        public GameForm()
        {
            InitializeComponent();
        }

        public GameForm(string firstUser, string secondUser)
        {
            _firstUserName = firstUser;
            _secondUserName = secondUser;
            InitializeComponent();
            
        }

        private void CreateField()
        {
            int width = 100;
            int height = 100;
            InitializateFirst(width, height);
            for (int i = 0; i < _fiedlSize; i++)
            {
                for (int j = 0; j < _fiedlSize; j++)
                {
                    if (i == 0 && j == 0)
                        continue;

                    this._field[i, j] = new Button();
                    this._field[i, j].Size = new Size(width, height);
                    this._field[i, j].BackColor = Color.DarkOliveGreen;
                    this._field[i, j].ForeColor = Color.Black;
                    this._field[i, j].Location = new Point(this._field[0,0].Location.X + (i * width),
                        this._field[0, 0].Location.Y + (j * height));
                    this._field[i, j].Click += ButtonClick;
                    this._field[i, j].Font = new Font("Times New Roman", 50);
                    this.Controls.Add(this._field[i, j]);

                }
            }
        }

        private void ButtonClick(object sender, System.EventArgs e)
        {
            if(_startTime.Year == 1)
                _startTime = DateTime.Now;
            Button b = sender as Button;
            b.Text = _isX ? "X" : "0";
            this._whoMoveL.Text = $"Now move: {(!_isX ? _firstUserName : _secondUserName)}";
            b.Enabled = false;
            _isX = !_isX;
            FinisGame(EndingGame());
        }

        private bool EndingGame()
        {
            int indH = 0;
            int indV = 0;
            int indD1 = 0;
            int indD2 = 0;
            for (int i = 0; i < _fiedlSize; i++)
            {
                for (int j = 0; j < _fiedlSize; j++)
                {
                    if (this._field[0, i].Text.Equals(this._field[j, i].Text) && this._field[0, i].Text != "")
                        indH++;
                    if (this._field[i, 0].Text.Equals(this._field[i, j].Text) && this._field[i, 0].Text != "")
                        indV++;
                    if (i == j)
                        if (this._field[0, 0].Text.Equals(this._field[i, j].Text) && this._field[0, 0].Text != "" && this._field[i, j].Text != "")
                            indD1++;
                    if(i+j == _fiedlSize-1)
                        if (this._field[0, this._fiedlSize - 1].Text.Equals(this._field[i, j].Text) && this._field[0, this._fiedlSize - 1].Text != "")
                        indD2++;

                }
                if(indH == this._fiedlSize || indV == this._fiedlSize || indD1 == this._fiedlSize || indD2 == this._fiedlSize)
                {
                    return true;
                }
                indH = 0;
                indV = 0;
            }

            return false;
        }

        private void FinisGame(bool finish)
        {
            
            if (finish)
            {
                _whoMoveL.Text = "";
                MessageBox.Show($"{(!_isX ? _firstUserName : _secondUserName)} win", "Winer", MessageBoxButtons.OK, 
                    MessageBoxIcon.Information);
                BlockButtons();
                _endTime = DateTime.Now;
                SaveToFile(true);
                this.Close();
                return;
            }
            if (finish == false)
            {
                foreach (var b in this._field)
                {
                    if (b.Enabled == true)
                    {
                        return;
                    }
                }
                _whoMoveL.Text = "";
                MessageBox.Show("Draw");
                _endTime = DateTime.Now;
                SaveToFile(false);
                BlockButtons();
                this.Close();
            }

        }

        private void BlockButtons()
        {
            for (int i = 0; i < this.Controls.Count; i++)
            {
                this.Controls[i].Enabled = false;
            }
        }

        private void InitializateFirst(int width, int height)
        {
            this._field[0, 0] = new Button();
            this._field[0, 0].Size = new Size(width, height);
            this._field[0, 0].BackColor = Color.DarkOliveGreen;
            this._field[0, 0].ForeColor = Color.Black;
            this._field[0, 0].Location = new Point((this.ClientRectangle.Width / 2) - (width * 2 - width / 2),
                (this.ClientRectangle.Height / 2) - (height * 2 - height / 2));
            this._field[0, 0].Click += ButtonClick;
            this._field[0, 0].Font = new Font("Times New Roman", 50);
            this.Controls.Add(_field[0, 0]);
        }

        private void SaveToFile(bool win)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(_startTime.ToString() + " ");
            sb.Append($"{_firstUserName} playing with {_secondUserName} ");
            if (win)
                sb.Append($"Winner: {(!_isX ? _firstUserName : _secondUserName)} ");
            else
                sb.Append($"Draw! ");
            sb.Append(_endTime.ToString() + "\n");

            if (File.Exists("history.txt"))
                File.AppendAllText("history.txt", sb.ToString());
            else 
                File.WriteAllText("history.txt", sb.ToString());
        }
    }
}
