﻿using System.Drawing;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CreateField()
        {
            int width = 100;
            int height = 100;
            InitializateFirst(width, height);
            for (int i = 0; i < _fiedlSize; i++)
            {
                for (int j = 0; j < _fiedlSize; j++)
                {
                    if (i == 0 && j == 0)
                        continue;

                    _field[i, j] = new Button();
                    _field[i, j].Size = new Size(width, height);
                    _field[i, j].BackColor = Color.DarkOliveGreen;
                    _field[i, j].ForeColor = Color.Black;
                    _field[i, j].Location = new Point(this.Controls[0].Location.X + (i * width),
                        this.Controls[0].Location.Y + (j * height));
                    _field[i, j].Click += ButtonClick;
                    _field[i, j].Font = new Font("Times New Roman", 50);
                    this.Controls.Add(_field[i, j]);

                }
            }
        }

        private void ButtonClick(object sender, System.EventArgs e)
        {
            Button b = sender as Button;
            b.Text = _isX ? "X" : "0";
            b.Enabled = false;
            _isX = !_isX;
            FinisGame(EndingGame());
        }

        private bool EndingGame()
        {
            int indH = 0;
            int indV = 0;
            int indD1 = 0;
            int indD2 = 0;
            for (int i = 0; i < _fiedlSize; i++)
            {
                for (int j = 0; j < _fiedlSize; j++)
                {
                    if (_field[0, i].Text.Equals(_field[j, i].Text) && _field[0, i].Text != "")
                        indH++;
                    if (_field[i, 0].Text.Equals(_field[i, j].Text) && _field[i, 0].Text != "")
                        indV++;
                    if (i == j)
                        if (_field[0, 0].Text.Equals(_field[i, j].Text) && _field[0, 0].Text != "" && _field[i, j].Text != "")
                            indD1++;
                    if(i+j == _fiedlSize-1)
                        if (_field[0, _fiedlSize - 1].Text.Equals(_field[i, j].Text) && _field[0, _fiedlSize - 1].Text != "")
                        indD2++;

                }
                if(indH == _fiedlSize || indV == _fiedlSize || indD1 == _fiedlSize || indD2 == _fiedlSize)
                {
                    return true;
                }
                indH = 0;
                indV = 0;
            }

            return false;
        }

        private void FinisGame(bool finish)
        {
            if (finish)
            {
                MessageBox.Show("Win");
                BlockButtons();
                return;
            }
            if (finish == false)
            {
                bool f = true;
                foreach (var b in _field)
                {
                    if (b.Enabled == true)
                    {
                        f = false;
                        break;
                    }
                }
                if (f)
                {
                    MessageBox.Show("Draw");
                }
            }

        }

        private void BlockButtons()
        {
            for (int i = 0; i < this.Controls.Count; i++)
            {
                this.Controls[i].Enabled = false;
            }
        }

        private void InitializateFirst(int width, int height)
        {
            _field[0, 0] = new Button();
            _field[0, 0].Size = new Size(width, height);
            _field[0, 0].BackColor = Color.DarkOliveGreen;
            _field[0, 0].ForeColor = Color.Black;
            _field[0, 0].Location = new Point((this.ClientRectangle.Width / 2) - (width * 2 - width / 2),
                (this.ClientRectangle.Height / 2) - (height * 2 - height / 2));
            _field[0, 0].Click += ButtonClick;
            _field[0, 0].Font = new Font("Times New Roman", 50);
            this.Controls.Add(_field[0, 0]);
        }
    }
}
